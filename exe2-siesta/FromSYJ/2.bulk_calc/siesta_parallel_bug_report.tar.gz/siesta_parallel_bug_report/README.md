# 병렬 벌크 계산 세그폴트 원인 분석

## TL;DR
SIESTA 5.4.2 컨테이너가 **작은 원시 셀 벌크 계산을 병렬(MPI ≥ 2)로 돌릴 때** 실공간 메쉬
분배 단계에서 SIGSEGV로 죽는다. **입력 문제가 아니다** — 동일 입력이 **직렬(np=1)에서는
정상 완료**한다. 트리거는 **auxiliary supercell + 병렬**이며, 근본 원인은 컨테이너의
`-O3 -march=native`(GCC 15.2.0) 빌드로 인한 병렬 메쉬-분배 루틴의 오컴파일로 추정된다.

- **임시 해결:** 작은 셀은 직렬(`--ntasks=1`)로 실행.
- **근본 해결:** `-O2`, `-march=native` 제거로 SIESTA 재빌드(관리자 필요).

---

## 증상
- 크래시 지점(모든 벌크 공통): `stdout.txt` 마지막 줄
  ```
  InitMesh: MESH = 24 x 24 x 216 = 124416
  New grid distribution [1]/[2]/[3]: sub = 2
  Setting up quadratic distribution...      ← 여기서 SIGSEGV
  ```
- SCF 진입 전(실공간 그리드/DHSCF 메쉬 분배 단계)에서 죽어, `.bands`/`.EIG`/`.DM` 등
  결과물은 생성되지 않음. `.err`에는 심볼 없는 backtrace + MPI_ABORT만 남음.

## 빌드 정보 (stdout 헤더)
```
Version         : 5.4.2
Compiler version: GNU-15.2.0
Compiler flags  : -fallow-argument-mismatch -O3 -march=native
Parallelisations: MPI
```

---

## 진단 과정 (Graphene 밴드 계산, 동일 입력으로 코어 수만 변경)

| 실행 | 결과 |
|------|------|
| **np = 1 (직렬)** | ✅ **정상 완료** — SCF 수렴, 밴드 계산, `Job completed` (E ≈ −389 eV) |
| np = 2 | ❌ `Setting up quadratic distribution...` 에서 SIGSEGV |
| np = 4 | ❌ 동일 |
| np = 8 | ❌ 동일 |
| np = 16 | ❌ 동일 |
| np = 4 + `Diag.ParallelOverK T` | ❌ 동일 (대각화 병렬 방식과 무관 → **메쉬 분배** 문제 확정) |

→ **입력은 정상**(직렬에서 물리적으로 타당한 결과), 크래시는 **병렬 + 메쉬 분배**에서만 발생.

---

## 결정적 원인: auxiliary supercell + 병렬

시스템별로 비교하면 크래시 조건이 명확해진다.

| 시스템 | 셀 크기 | auxiliary supercell | 병렬 | 결과 |
|--------|---------|---------------------|------|------|
| H2O (분자) | 큰 박스 (20 Å) | **없음** (1×1×1) | np=16 | ✅ |
| SiH (64 Si + H) | 10.86 Å | **없음** | np=4 | ✅ |
| Graphene | 2.46 Å | 9×9×1 = 81 | np=1 | ✅ |
| Graphene | 2.46 Å | 9×9×1 = 81 | np=4 | ❌ |
| GaAs | 원시 셀 (zinc-blende) | 5×5×5 = 125 | np=4 | ❌ |
| MgO | 원시 셀 (rocksalt) | 7×7×7 = 343 | np=4 | ❌ |

> GaAs/MgO 의 supercell·결과는 이 번들 `gaas/`·`mgo/` 의 np=4 재실행에서 실제 관측된 값이다.

- **조건: (auxiliary supercell 존재) AND (병렬 실행) → 크래시.**
- 작은 원시 셀은 오비탈 반경이 셀을 넘어 주기적 이미지(auxiliary supercell)를 만든다.
  이 supercell의 궤도 이미지를 병렬 메쉬에 분배하는 경로에서 죽는다.
- 분자(고립계, 큰 박스)나 SiH(큰 셀)는 supercell이 없어 그 경로를 밟지 않으므로 병렬에서도 정상.

---

## 근본 원인 (추정)
병렬에서만, 입력과 무관하게, 특정 코드 경로(auxiliary-supercell 메쉬 분배)에서 재현되는
세그폴트는 **공격적 최적화로 인한 오컴파일**의 전형적 증상이다:
- 최신 **GCC 15.2 + `-O3 -march=native`** 조합은 SIESTA 메쉬 루틴(인덱스 산술/SIMD 루프)을
  잘못 벡터화하여 잘못된 메모리 참조를 만들 수 있음.
- 직렬 경로나 supercell 없는 경로는 문제의 루프를 밟지 않아 정상 동작.

---

## 해결책

1. **임시(즉시 가능):** 작은 벌크 셀은 **직렬**로 실행.
   - `slm_siesta_run`의 `#SBATCH --ntasks=1` (mpirun `-np 1`).
   - 2원자 graphene 등은 직렬로도 수 초 내 완료되어 실용상 충분.
2. **근본(권장):** 컨테이너의 SIESTA를 **`-O2`로, `-march=native` 제거**하여 재빌드
   (필요시 `-fno-tree-vectorize`). 관리자에게 요청. 병렬 전용·입력 무관 크래시이므로
   이 방향이 정답.
3. **검증 팁:** 새 빌드에서 위 표의 Graphene np=4가 통과하면 해결된 것.

---